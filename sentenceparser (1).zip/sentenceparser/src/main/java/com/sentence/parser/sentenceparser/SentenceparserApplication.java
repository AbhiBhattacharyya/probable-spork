package com.sentence.parser.sentenceparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentenceparserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SentenceparserApplication.class, args);
	}

}

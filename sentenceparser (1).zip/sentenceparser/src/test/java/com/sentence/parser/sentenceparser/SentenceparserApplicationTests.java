package com.sentence.parser.sentenceparser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentenceparserApplicationTests {

	@Test
	void contextLoads() {
	}

}
